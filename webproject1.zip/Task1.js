document . querySelector (”button”) . addEventListener (” click ” , function () {
    2
    3 }) ;
    a l ert (”Product added to cart”) ;